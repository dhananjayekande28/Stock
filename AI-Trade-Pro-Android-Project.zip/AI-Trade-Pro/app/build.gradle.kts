plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aitradepro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aitradepro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-demo"
    }
}
